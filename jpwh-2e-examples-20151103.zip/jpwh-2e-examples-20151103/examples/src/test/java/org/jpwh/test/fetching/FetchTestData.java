package org.jpwh.test.fetching;

import org.jpwh.shared.util.TestData;

public class FetchTestData {

    public TestData items;
    public TestData bids;
    public TestData users;

}
