package org.jpwh.model.filtering.interceptor;

public interface Auditable {
    public Long getId();
}
