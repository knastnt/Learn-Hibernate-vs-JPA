package org.jpwh.model.advanced.converter;

public class GermanZipcode extends Zipcode {

    public GermanZipcode(String value) {
        super(value);
    }
}
