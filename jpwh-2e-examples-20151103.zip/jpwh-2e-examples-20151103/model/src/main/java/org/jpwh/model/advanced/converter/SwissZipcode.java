package org.jpwh.model.advanced.converter;

public class SwissZipcode extends Zipcode {

    public SwissZipcode(String value) {
        super(value);
    }
}
