package org.jpwh.web.dao;


import org.jpwh.web.model.Bid;

public interface BidDAO extends GenericDAO<Bid, Long> {}
