package org.jpwh.web.dao;

import org.jpwh.web.model.User;

public interface UserDAO extends GenericDAO<User, Long> {

}
