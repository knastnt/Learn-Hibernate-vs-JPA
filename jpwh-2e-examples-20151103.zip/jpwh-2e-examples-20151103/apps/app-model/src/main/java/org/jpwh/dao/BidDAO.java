package org.jpwh.dao;

import org.jpwh.model.Bid;

public interface BidDAO extends GenericDAO<Bid, Long> {}
