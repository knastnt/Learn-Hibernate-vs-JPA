package org.jpwh;

public interface Constants {

    public static final String ID_GENERATOR = "ID_GENERATOR";
    public static final String ID_GENERATOR_SEQUENCE_NAME = "JPWH_SEQUENCE";

}
