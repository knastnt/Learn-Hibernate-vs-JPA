package org.jpwh.stateful;

public interface AuctionService extends RemoteAuctionService {
    // Methods that are only available locally are here
}
